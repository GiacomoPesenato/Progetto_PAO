#include "sensorevisitor.h"

sensoreVisitor::sensoreVisitor() {}
